# pd-xray-cwl_lam7o3-p021 — provenance

A high-entropy perovskite, La(Ti,Cr,Mn,Fe,Co,Ni,Cu)O₃, against a synchrotron X-ray powder pattern
from the P02.1 beamline at PETRA III.

## Sources

- **Model:** diffraction-lib's tutorial `refine-lam7o3-p021` (develop `cb2cda7b`): the Pnma structure
  with seven cations sharing the B site in equal parts, the constraints tying the six other B-site
  displacements to Ti's and O2's to O1's, the wavelength 0.207109 Å, the pseudo-Voigt with
  Thompson-Cox-Hastings broadening (Y fixed at 0, as the tutorial has it), the excluded regions below
  2° and from 15° to 20°, and every parameter the tutorial frees.
- **Data:** `data/hep7c-xray-synchrotron.dat`, dataset `meas-hep7c-xray-synchrotron` of the repository
  `easyscience/diffraction` at commit `3ec801667904578ea39f1a4f4aa941866543a669` (path
  `data/measured/hep7c-xray-synchrotron.dat`), sha256
  `9337ae90cff8bba8dec359dc768c937767f8fd6e0305b6c2c916b9f3963d9a01`, licence BSD-3-Clause. The file
  has no uncertainties; the project gives each point √I, and 1 where I < 1 (only zero counts, all in
  the excluded region), as diffraction-lib's loader does.

## Start

The start a user's own measurement would have, built by `tools/cli_projects/build_catalogue_projects.py`:
zero shift 0; U, V, W and X at the tutorial's values, already one significant figure (0.04, −0.01, 0.001,
0.1); Biso 0.5 on every site; the tutorial's free coordinates to two decimals (La z 0.004 becomes 0.0);
the owner's 20 line-segment background points, flat at 300 counts; scale 0.000005; the tutorial's cell
(5.5, 7.7, 5.5 Å). Free: the cell, scale, zero shift, U, V, W, X, the 20 background points, La x/z,
O1 x/z, O2 x/y/z and the Biso of La, Ti and O1 (39 parameters).

**The background.** The tutorial's automatic estimate is not capped in its number of points, so its
background follows the capillary and air scattering under the first peaks closely. The owner chose 20 points
(2026-10-22): ids and positions as he gave them, denser between 2° and 5°, each starting at 300 counts.

**The descent.** The project declares `_minimizer.descent fast_descent`. With the default descent the fit
stops at R<sub>wp</sub> 3.04 % and reduced χ² 0.64 with O1 x at 0.499, from these flat points and equally from
the owner's own fitted intensities; the fast descent (and the multistart one) reaches the tutorial's minimum.

## Differences from the tutorial

- The tutorial estimates its background automatically, first without and then with the model; here it
  starts flat.
- edi's X-ray scattering uses the it1992 form factors and the sasaki1989 dispersion corrections.
- No polarization correction is declared.

## Result from this start (local diagnostic)

From this start edi converges in 40 iterations (18 before the fast descent took its damping from
the predicted χ² drop, 2026-11-04) to R<sub>wp</sub> 1.64 % and reduced χ² 0.187, with
a 5.46218, b 7.73302, c 5.49022 Å, O1 x 0.5078 and scale 3.686 × 10⁻⁶. diffraction-lib's own tutorial
record reports R<sub>wp</sub> 1.51 %, reduced χ² 0.16, a 5.46225, b 7.73307, c 5.49024 Å, O1 x 0.50828
and scale 3.653 × 10⁻⁶.

**Re-pinned 2026-11-07.** Under Shift/s.u. a fit now also needs the full undamped step to be below the tolerance, and a
χ² plateau tries that step once before it ends the fit. Pins retaken with `python tools/checks/cli_projects.py` linked
against crysta `4643af79`, `OMP_NUM_THREADS=1`: iterations 40 → 38.

**Re-pinned 2026-11-11.** The default stop rules are now the χ² change and Shift/s.u. together (Shift/s.u. counting only
after two consecutive iterations), and the project no longer declares the Shift/s.u. rule alone. Measured with `python
-m edi fit --report machine --verbosity full` linked against crysta `edab5435`, `OMP_NUM_THREADS=4`: iterations 38 → 39.
No `reference` value moved.
