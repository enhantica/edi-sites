# pd-neut-cwl_lbco-hrpt: provenance

Built by `tools/cli_projects/build_catalogue_projects.py` (`catalogue_cw_cases.py`).

## Sources

- **Data:** the HRPT (PSI) pattern of `pd-neut-cwl_lbco-hrpt_start-4`, read from its `_data` loop unchanged: the 3098
  points of diffraction-lib's dataset `meas-lbco-hrpt` (`data/measured/lbco-hrpt.xye` in `easyscience/diffraction` at commit `3ec801667904578ea39f1a4f4aa941866543a669`, sha256
  `70dba3f642b394f0e7e7802a8637e0e287164562671993ee0701b813c902e360`), licence BSD-3-Clause.
- **Model:** diffraction-lib's tutorial `refine-lbco-hrpt-from-data` (develop `cb2cda7b`): La0.5Ba0.5CoO3 in
  `P m -3 m`, La and Ba sharing the `1a` site, Thompson-Cox-Hastings pseudo-Voigt, wavelength 1.494 Å fixed, excluded
  regions 0-5° and 165-180°, five background points. As in the tutorial's last step, Ba's Biso is tied to La's.

## The start

- **Start:** the 2θ zero at 0.3°, half HRPT's calibrated 0.6° (the tutorial's start), by the owner's choice;
  U, V, W, Y at one significant figure of the fitted values (0.08, -0.1, 0.1, 0.08); Biso 0.5 on every site; cell
  3.88 Å as the tutorial starts it; scale 9; a flat background at the level read off the pattern.
- **Why the zero is not 0:** this pattern's zero shift is 0.62°. From 0, with the cell at 3.88 Å, the high-angle peaks
  line up but the low-angle ones sit up to 0.5° away, more than their width, and a fit with every parameter free
  settles at R<sub>wp</sub> 39 % with a quarter of the scale, broad peaks and a negative Co Biso. With only the scale,
  zero, cell and background free it finds the zero from 0; with everything free it needs a start of 0.25° or more,
  and from 0.3° it reaches R<sub>wp</sub> 7.23 %.
- **Free (15):** the cell, the Biso of La (Ba follows), Co and O, the zero shift, U, V, W, Y, the scale and the five
  background points.
- **Left out:** the tutorial's automatic background estimate (a flat background stands in for it), its cryspy and
  CrysFML calculator switches and its lmfit minimizer choice; edi uses crysta.

**Re-pinned 2026-11-04.** The project declares the Shift/s.u. stop rule (`_minimizer.stop_rule shift_su`, 0.1; the χ²
change still ends a fit when it passes first), as every example does. Pins retaken with `python -m edi fit --report
machine` linked against crysta `609586d9`, `OMP_NUM_THREADS=1`: iterations 8 → 7.

**Re-pinned 2026-11-11.** The default descent now runs fast descent and the ladder for three iterations each from the
start and continues with the one at the lower χ². Measured with `python -m edi fit --report machine --verbosity full`
linked against crysta `edab5435`, `OMP_NUM_THREADS=4`: iterations 7 → 5. No `reference` value moved.
