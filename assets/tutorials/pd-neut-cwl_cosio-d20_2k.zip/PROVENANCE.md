# pd-neut-cwl_cosio-d20_2k: provenance

## Sources

- **Data:** the D20 (ILL) pattern at 2.344 K, `002p3440_all594631.dat` of the 213-file Co₂SiO₄ temperature scan
  `cosio-d20-scan-213f.zip` in `easyscience/diffraction` (`data/measured/`, zip sha256
  `1bd6e37d693fd47a5ff7e95e86aeb94eb8f645c8fd44fed31ab8d7255b377e23`; file sha256
  `eb0b0ebdefb0b2225cebd3d7c244d5c94132b181cd367bbba001841f89961578`), licence BSD-3-Clause. Its 1506 points with a
  non-zero uncertainty are read unchanged into the experiment's `_data` loop; the two last points, with zero
  uncertainty, are left out.
- **Model:** the nuclear structure of `pd-neut-cwl_cosio-d20`, with the cell, coordinates, zero shift and profile terms
  of a FullProf 8.40 fit of this pattern, the displacement parameters of a FullProf
  fit of the 56.8 K pattern (Co1 and Co2 share one value), and the magnetic structure of ISODISTORT's description of
  Co₂SiO₄ in Pnma.1 (irrep mGM1+): its eight operators. The moments start at Co1 (2, 2, 2) and Co2 (0, 2, 0) μB, so the
  magnetic structure shows clearly before the fit; from it the fit reaches the same minimum as from (0, 1, 0) on both
  sites (Rwp 4.70 %, Co1 (1.01, 3.02, 0.0) μB and Co2 2.62 μB along b, run of 2026-11-10).
- **Stop rule:** Shift/s.u. 0.1, as every example (the owner, 2026-11-04): the fit ends at 37 iterations from the
  start above, reduced χ² 6.25 (2026-11-10).
- **Form factor:** Co²⁺ in the dipole approximation, ⟨j0⟩ + C₂⟨j2⟩ (the owner, 2026-11-04), with C₂ fitted from 0. At
  the χ² change's end point C₂ = 0.589(54), the value the 213-file scan holds (Shift/s.u. ends at 0.603); counted
  against the total moment J as C₂ = 2/g − 1, so g ≈ 1.26, near the free Co²⁺ ion's g_J = 4/3 (⁴F₉/₂, C₂ = 0.50).
  Against ⟨j0⟩ alone, reduced χ² falls from 6.712 to 6.246 and both moments come out a little smaller: Co1 |M| 3.25 to
  3.18 μB, Co2 2.74 to 2.62 μB.
- **Reference:** A. Sazonov et al., *Magnetic behaviour of synthetic Co₂SiO₄*, Acta Cryst. B65 (2009) 664–675.
- **Excluded:** 0–6° and 150–180°, and 64.65–64.74°, which holds only the dead D20 detector cell at 64.6953°.
- **Background:** sixteen points, none between 7.6° and 12.6°, so none sits under the first magnetic peak.
- **Profile:** the Thompson-Cox-Hastings pseudo-Voigt with Finger-Cox-Jephcoat asymmetry, which describes the
  low-angle flank of the first magnetic peak. S/L and D/L share one free value (the analysis constrains D/L to S/L),
  fitted from 0: the profile is symmetric under swapping them, so freed separately they trade off along a flat valley
  and only their common value is determined. The fit gives 0.0627(9).
- **Descent:** the default. The fast descent, which this project declared before, reaches the same minimum from this
  start (reduced χ² 6.71250 against 6.71243, every parameter within 0.05 s.u.) in 104 iterations instead of 57.
- **Expected values:** `expected.json` pins this project's own fit as **regression pins**, which gate drift, not
  correctness: reduced χ² 6.248741768 after 22 iterations and C₂ 0.6028460903, from `python -m edi fit --report
  machine` linked against crysta `609586d9`, `OMP_NUM_THREADS=1`; the 42 free parameters are counted from the model.
  FullProf's form factor here is ⟨j0⟩ alone (`MCO2`), so its fit is compared with edi's fit of a copy using ⟨j0⟩ (the
  `form-factor-j0` variant), on the same pattern, background, profile and magnetic model
  (`knowledge/fitting/fullprof/pd-neut-cwl_cosio-d20_2k/`, S/L and D/L both held at 0.0619): Rwp within 5 % of
  FullProf's 4.91 %, and the three well-determined moment components within 0.15 μB of FullProf's, about four of its
  standard deviations. Co1's Mz is not compared: powder data barely determine it.

**Re-pinned 2026-11-07.** Under Shift/s.u. a fit now also needs the full undamped step to be below the tolerance, and a
χ² plateau tries that step once before it ends the fit. Pins retaken with `python tools/checks/cli_projects.py` linked
against crysta `4643af79`, `OMP_NUM_THREADS=1`: reduced_chi_square 6.248741768 → 6.245734584; iterations 22 → 57;
param.Co.j2_coefficient.value 0.6028460903 → 0.5894931888.

**Re-pinned 2026-11-09.** crysta now uses the CODATA magnetic scattering length, 2.69542 fm per Bohr magneton instead
of the rounded 2.695, so every magnetic intensity is 3.1e-4 higher (crysta `769cf965`). The fit reaches the same
minimum by a shorter path. Pins retaken with `python -m edi fit <copy> --report machine` linked against crysta
`361b2b64`, `OMP_NUM_THREADS=1`: reduced_chi_square 6.245734584 → 6.245812633; iterations 57 → 41;
param.Co.j2_coefficient.value 0.5894931888 → 0.5896782533, 0.003 of its s.u.

**Re-pinned 2026-11-11.** A refused step on a magnetic moment is retried at the length a quadratic model of the residual
predicts; the default descent now runs fast descent and the ladder for three iterations each from the start and
continues with the one at the lower χ². Measured with `python -m edi fit --report machine --verbosity full` linked
against crysta `edab5435`, `OMP_NUM_THREADS=4`: reduced_chi_square 6.245812633 → 6.245620875; iterations 41 → 23;
param.Co.j2_coefficient.value 0.5896782533 → 0.5867252778. No `reference` value moved.

**Re-measured 2026-11-11** with the new starting moments and the default descent's three-iteration probes, on the
merged tree (crysta `f4620764`), with `python -m edi fit --report machine` and the Python API for the j2 weight:
reduced_chi_square 6.245620875 → 6.245620606; iterations 23 → 14; param.Co.j2_coefficient.value 0.5867252778 →
0.5867186461. No `reference` value moved.

**Re-measured 2026-11-11** after the tutorial moved to five stages from everything fixed (scale, 2θ zero, cell,
moments and j2; background; displacements and positions; peak widths; asymmetry). The finished fit now also frees the
isotropic displacements of Co1, Si, O1, O2 and O3 (Co2's follows Co1's by the constraint), so the project marks them
with `()`. Measured on crysta `965dba82` with `python -m edi fit --report machine`, `OMP_NUM_THREADS=4`, and the Python
API for the j2 weight: n_free 42 → 47 (the `reference` count moves with the freed displacements); reduced_chi_square
6.245620606 → 6.24919781, a different minimum 0.06 % higher; iterations 14 → 20; param.Co.j2_coefficient.value
0.5867186461 → 0.6094163294.
