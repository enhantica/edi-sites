# pd-neut-cwl_cosio-d20: provenance

Built by `tools/cli_projects/build_catalogue_projects.py` (`catalogue_cw_cases.py`).

## Sources

- **Data:** the D20 (ILL) pattern of `pd-neut-cwl_cosio-d20_start-4`, read from its `_data` loop unchanged: the 1418
  points of diffraction-lib's dataset `meas-cosio-d20` (`data/measured/cosio-d20.xye` in `easyscience/diffraction` at commit `3ec801667904578ea39f1a4f4aa941866543a669`, sha256
  `72ff3c5902cc9e87b7a9a6f4d87081e6367f1477a7958914e3d89c87ddc164e9`), licence BSD-3-Clause.
- **Model:** diffraction-lib's tutorial `refine-cosio-d20` (develop `cb2cda7b`) and `pd-neut-cwl_cosio-d20_start-4`:
  Co2SiO4 in `P n m a`, wavelength 1.87 Å fixed, 14 background points, and the tutorial's tie of Co2's Biso to Co1's.
  The peak shape is the source project's Thompson-Cox-Hastings pseudo-Voigt without asymmetry; the tutorial uses a
  pseudo-Voigt with Bérar-Baldinozzi asymmetry and frees one asymmetry term.

## The start

- **Start:** zero shift 0; U, V, W, Y at one significant figure of the fitted values (0.2, -0.5, 0.4, 0.01); Biso 0.5
  on every site; coordinates rounded to two decimals; cell 10.3, 6.0, 4.8 Å as the tutorial starts it; oxygen
  occupancies 1; scale 1; a flat background at the level read off the pattern.
- **Free (42):** the cell, the 11 free coordinates, the Biso of Co1 (Co2 follows), Si and the three oxygens, the three
  oxygen occupancies, the zero shift, U, V, W, Y, the scale and the 14 background points.
- **Descent:** the project declares `_minimizer.descent fast_descent`. From this start the default descent stops in a
  shallower minimum.
- **Left out:** the tutorial's minimizer choice; edi uses crysta.

**Re-pinned 2026-11-04.** The project declares the Shift/s.u. stop rule (`_minimizer.stop_rule shift_su`, 0.1; the χ²
change still ends a fit when it passes first), as every example does. Pins retaken with `python -m edi fit --report
machine` linked against crysta `609586d9`, `OMP_NUM_THREADS=1`: iterations 22 → 11.

**Re-pinned 2026-11-07.** Under Shift/s.u. a fit now also needs the full undamped step to be below the tolerance, and a
χ² plateau tries that step once before it ends the fit. Pins retaken with `python tools/checks/cli_projects.py` linked
against crysta `4643af79`, `OMP_NUM_THREADS=1`: iterations 11 → 38.

**Re-pinned 2026-11-11.** The default stop rules are now the χ² change and Shift/s.u. together (Shift/s.u. counting only
after two consecutive iterations), and the project no longer declares the Shift/s.u. rule alone. Measured with `python
-m edi fit --report machine --verbosity full` linked against crysta `edab5435`, `OMP_NUM_THREADS=4`: iterations 38 → 39.
No `reference` value moved.

**Re-pinned 2026-11-14.** When a fit accepts the undamped Gauss-Newton step on a chi-square plateau, crysta now drops the damping back to its starting value (crysta `6cbe0e60`). Same minimum, chi-square and Rwp within their bounds. Measured with `python -m edi fit --report machine` linked against crysta `81b4f6db`, `OMP_NUM_THREADS=4`: iterations 39 → 22.
