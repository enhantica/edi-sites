# SPDX-License-Identifier: BSD-3-Clause
"""``python -m edi`` — edi's command-line entry point.

    python -m edi fit <project-dir> [--dry] [--verbosity ...] [--report ...] [--stream]
    python -m edi calc <project-dir> [--dry] [--verbosity ...] [--report machine|human]
    python -m edi undo <project-dir> [--dry] [--verbosity ...] [--report machine|human]
    python -m edi report <project-dir> [--check] [--output PATH] [--offline|--online]
                         [--x-axis ...] [--correlation-threshold X]
                         [--exclude KEY ... | --include-all]
                         [--colour-scheme NAME] [--correlation-experiment NAME]

This exists because an example script was doing the job: ``examples/fit_ncaf.py`` had accreted
argument parsing, verbosity handling and two output formats, which made it an undeclared
public interface with no stability contract and a path that breaks the moment the file is
renamed. The example is an example again; this is the supported entry point.

**No formatting lives here.** Both reports are rendered by ``edi::core``
(``edi.machine_report`` and the streaming formatters), so this module, a notebook, and the later
desktop/WASM surfaces all render one implementation. This file only parses arguments, chooses a
stream, and prints.

Two channels with different jobs:

* ``--report machine`` is the *verification* channel — the versioned ``key=value`` record
  defined by crysta and emitted by the engine's own emitter, so ``crysta fit`` and
  ``edi fit`` can be compared with ``diff`` rather than by reading two terminals.
* ``--report human`` (the default) is the *user* channel, owned by edi and free to evolve.

Streams follow the contract: the selected report goes entirely to **stdout**, and **stderr carries
only what is not part of the contract** — warnings and errors. That is what keeps
``diff <(crysta fit P --verbosity compact) <(python -m edi fit P --report machine --verbosity
compact)`` a single comparison.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import math
import os
import signal
import sys
import tempfile
import time
from pathlib import Path
from typing import Self

import edi
from edi import _edi as _native
from edi import _project_output as _output
from edi._machine_records import schema_line

# One verbosity for both channels, so --verbosity means the same thing whichever --report is
# chosen.
_VERBOSITY = {
    'off': edi.VerbosityEnum.OFF,
    'compact': edi.VerbosityEnum.COMPACT,
    'full': edi.VerbosityEnum.FULL,
}


def _add_download_commands(subcommands: argparse._SubParsersAction) -> None:
    """diffraction-lib's download commands and options, over EasyDiffraction's collection."""
    source_help = (
        "a collection's base URL or folder (default: EDI_COLLECTION, else EasyDiffraction's)"
    )
    tutorials_help = (
        "the tutorials' base URL or folder (default: EDI_TUTORIALS, else the docs site)"
    )
    list_data = subcommands.add_parser('list-data', help="list the collection's entries, numbered")
    list_data.add_argument(
        '--kind', choices=('structure', 'experiment', 'data', 'project'), default=''
    )
    download_data = subcommands.add_parser(
        'download-data', help='download an entry by id or listing number; a project is unpacked'
    )
    download_data.add_argument('name', help='the entry id, or its number in list-data')
    download_data.add_argument('-d', '--destination', metavar='DIR', default='data')
    list_tutorials = subcommands.add_parser('list-tutorials', help='list the tutorials, numbered')
    download_tutorial = subcommands.add_parser(
        'download-tutorial', help='download a tutorial by id or listing number'
    )
    download_tutorial.add_argument('name', help='the tutorial id, or its number in list-tutorials')
    download_tutorial.add_argument('-d', '--destination', metavar='DIR', default='tutorials')
    download_tutorial.add_argument('--ipynb', action='store_true', help='the notebook (default)')
    download_tutorial.add_argument('--py', action='store_true', help='the Python script')
    download_all = subcommands.add_parser('download-all-tutorials', help='download every tutorial')
    download_all.add_argument('-d', '--destination', metavar='DIR', default='tutorials')
    for parser in (download_data, download_tutorial, download_all):
        parser.add_argument('-o', '--overwrite', action='store_true')
    for parser, help_text in (
        (list_data, source_help),
        (download_data, source_help),
        (list_tutorials, tutorials_help),
        (download_tutorial, tutorials_help),
        (download_all, tutorials_help),
    ):
        parser.add_argument('--source', metavar='URL_OR_FOLDER', default=None, help=help_text)


LOG_LEVELS = ('error', 'warning', 'info', 'debug')


def take_log_level(argv: list[str]) -> tuple[str, list[str]]:
    """The --log-level value (warning when absent) and the arguments without it."""
    level, kept, index = 'warning', [], 0
    while index < len(argv):
        argument = argv[index]
        if argument == '--log-level' and index + 1 < len(argv):
            level, index = argv[index + 1], index + 2
            continue
        if argument.startswith('--log-level='):
            level = argument.split('=', 1)[1]
        else:
            kept.append(argument)
        index += 1
    return level, kept


def _positive_count(value: str) -> int:
    if not value.isascii() or not value.isdecimal():
        raise argparse.ArgumentTypeError('requires a positive integer')
    digits = value.lstrip('0')
    if not digits or len(digits) > 10 or int(digits) > 2**31 - 1:
        raise argparse.ArgumentTypeError('requires a positive integer within the supported range')
    return int(digits)


def _thread_count(value: str) -> int:
    return 0 if value == 'auto' else _positive_count(value)


def _add_performance_options(fit: argparse.ArgumentParser, calc: argparse.ArgumentParser) -> None:
    for parser in (fit, calc):
        parser.add_argument(
            '--threads',
            type=_thread_count,
            default=0,
            metavar='auto|N',
            help='threads per calculation (default: auto)',
        )
    fit.add_argument(
        '--parallel-fits',
        type=_positive_count,
        default=1,
        metavar='N',
        help='scan files fitted together (default: 1); each uses one thread and in a sequential '
        "scan each group starts from the preceding group's result",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='python -m edi',
        description='Fit a complete .edi project directory.',
    )
    # Taken out of the arguments wherever it stands, as the standalone edi takes it (main).
    parser.add_argument(
        '--log-level',
        choices=LOG_LEVELS,
        help="messages to show: 'error', 'warning' (the default), 'info' or 'debug'",
    )
    subcommands = parser.add_subparsers(dest='command', required=True)
    # `fit` only. A speculative subcommand family would be inventing an interface nobody asked for;
    # this is what exists and what was requested.
    fit = subcommands.add_parser('fit', help='fit a project directory')
    fit.add_argument(
        'project',
        help='project directory (structures/, experiments/, analysis/) with embedded measured'
        ' data',
    )
    # The minimization conditions — descent, chi-square tolerance and iteration budget — are
    # declared in the project's analysis/analysis.edi (`_minimizer.*`), never on this command
    # line: like diffraction-lib's `fit`, it takes the project and --dry (plus the output-channel
    # options below). The valid descent ids are documented beside the other analysis.edi fields
    # (docs/user/guides/complete-project-loading.md).
    fit.add_argument(
        '--verbosity',
        choices=('off', 'compact', 'full'),
        default='compact',
        help="how much to report: 'off' prints nothing, 'compact' the summary, 'full' adds "
        'per-bank R-factors, every iteration and every fitted parameter (default: compact)',
    )
    fit.add_argument(
        '--report',
        choices=('machine', 'human'),
        default='human',
        help="which channel to print: 'human' is the readable view, 'machine' the versioned "
        'key=value record that is byte-comparable with `crysta fit` (default: human)',
    )
    fit.add_argument(
        '--stream',
        action='store_true',
        help='stream live per-iteration progress. The human report streams a single fit (rows '
        'appear as each iteration completes); this flag adds live record=progress records to the '
        'machine report, emitted before the terminal record=fit (default: off, so machine output '
        'is byte-identical to a non-streamed run). A SCAN (_fitting_mode.type sequential or '
        'independent) reports per-FILE progress on the human channel instead — one self-updating '
        'line on a TTY, one line per file otherwise, per-iteration rows at --verbosity full — '
        'and never streams on the machine channel: its per-file iteration sequences a single-fit '
        'progress record cannot honestly represent.',
    )
    # A fit PERSISTS the fitted project by default (the anchor's `fit [--dry]`); --dry opts
    # out and leaves the project tree byte-identical.
    fit.add_argument(
        '--dry',
        action='store_true',
        help='fit without writing: leave the project tree byte-identical (the default writes '
        'the fitted project back into its own directory)',
    )
    fit.add_argument(
        '--output',
        metavar='DIR',
        help='save the project into DIR and write the results there; a .zip project is written '
        'back only this way: an input archive is never written as the output',
    )
    # The forward calculation, mirroring `crysta <project-dir> calc`. The output is the
    # versioned record=calc machine record, byte-comparable with crysta's by construction
    # (both render through crysta's own emitter).
    calc = subcommands.add_parser('calc', help='forward-calculate a project directory')
    _add_performance_options(fit, calc)
    calc.add_argument(
        'project',
        help='project directory (structures/, experiments/, analysis/) with embedded measured '
        'data or a declared _data_range grid',
    )
    calc.add_argument(
        '--dry',
        action='store_true',
        help='calculate without writing: leave the project tree byte-identical (the default '
        'writes the _data_calc series into each experiment file, replacing any previous '
        'calculated block)',
    )
    calc.add_argument(
        '--verbosity',
        choices=('off', 'compact', 'full'),
        default='compact',
        help="how much to report: 'off' prints nothing; 'compact' and 'full' are identical "
        'for a calculation — it has no iterations or parameters (default: compact)',
    )
    calc.add_argument(
        '--report',
        choices=('machine', 'human'),
        default='machine',
        help="which channel to print: 'machine' (the default) is the versioned record=calc "
        "byte-comparable with `crysta <dir> calc`; 'human' is the readable view",
    )
    calc.add_argument(
        '--output',
        metavar='DIR',
        help='save the project into DIR and write the results there; a .zip project is written '
        'back only this way: an input archive is never written as the output',
    )
    export = subcommands.add_parser(
        'export', help='write a project folder as one .zip archive (edi ADR-0052)'
    )
    export.add_argument('project', help='project directory, its project.edi, or a .zip')
    export.add_argument('-o', '--output', required=True, metavar='FILE', help='the .zip to write')
    undo = subcommands.add_parser('undo', help='undo the last fit of a project directory')
    undo.add_argument('project', help='project directory previously fitted (and saved)')
    undo.add_argument(
        '--dry',
        action='store_true',
        help='preview: report what undo would restore without writing anything',
    )
    undo.add_argument(
        '--verbosity',
        choices=('off', 'compact', 'full'),
        default='compact',
        help="how much to report: 'off' prints nothing, 'compact' the summary, 'full' adds "
        'every restored parameter (default: compact)',
    )
    undo.add_argument(
        '--report',
        choices=('machine', 'human'),
        default='machine',
        help="which channel to print: 'machine' (the default) is the versioned key=value record "
        "byte-comparable with `crysta undo`; 'human' is the readable view",
    )
    collection = subcommands.add_parser(
        'collection',
        help="list, find or fetch entries of EasyDiffraction's data collection (edi ADR-0068)",
    )
    collection.add_argument(
        '--source',
        metavar='URL_OR_FOLDER',
        default=None,
        help='the collection: a base URL or a folder holding index.json (default: '
        "EDI_COLLECTION, else EasyDiffraction's collection on GitHub)",
    )
    actions = collection.add_subparsers(dest='action', required=True)
    listing = actions.add_parser('list', help='list the entries, one line each')
    listing.add_argument(
        '--kind', choices=('structure', 'experiment', 'data', 'project'), default=None
    )
    finding = actions.add_parser('find', help='print one entry as JSON')
    finding.add_argument('id')
    fetching = actions.add_parser('fetch', help="copy or download an entry's file into a folder")
    fetching.add_argument('id')
    fetching.add_argument(
        '--into', metavar='DIR', default='.', help='the folder to write into (default: .)'
    )
    _add_download_commands(subcommands)
    report = subcommands.add_parser(
        'report',
        help="save a project's report into its reports folder, as the app's Save report does",
    )
    report.add_argument('project', help='project directory')
    report.add_argument(
        '--check',
        action='store_true',
        help='list each saved report as current, out of date or missing, writing nothing; '
        'exit 1 when one is not current',
    )
    report.add_argument(
        '--output',
        metavar='PATH',
        default=None,
        help="write the HTML report to PATH instead of saving the ticked formats; the project's "
        'saved reports and their rows are left as they are',
    )
    libraries = report.add_mutually_exclusive_group()
    libraries.add_argument(
        '--offline',
        dest='offline',
        action='store_const',
        const=True,
        default=None,
        help='embed the chart libraries in the HTML report, for this run',
    )
    libraries.add_argument(
        '--online',
        dest='offline',
        action='store_const',
        const=False,
        help='load the chart libraries from the web, for this run',
    )
    report.add_argument(
        '--x-axis',
        choices=('native', 'd_spacing'),
        default=None,
        help="the charts' x axis for this run: the experiment's own (2θ or TOF) or d-spacing",
    )
    report.add_argument(
        '--correlation-threshold',
        type=float,
        default=None,
        metavar='X',
        help='the correlation chart shows the parameters whose strongest correlation '
        'reaches X (0 to 1), for this run',
    )
    groups = report.add_mutually_exclusive_group()
    groups.add_argument(
        '--exclude',
        action='append',
        default=None,
        metavar='KEY',
        help='leave a group out for this run (charts, correlations, reflections, data, '
        'evolution); repeat for several',
    )
    groups.add_argument(
        '--include-all', action='store_true', help='leave no group out, for this run'
    )
    report.add_argument(
        '--colour-scheme',
        choices=('main', 'colourBlindSafe'),
        default=None,
        metavar='NAME',
        help="the figure palette whose light colours the report's charts take (default: main)",
    )
    report.add_argument(
        '--correlation-experiment',
        default=None,
        metavar='NAME',
        help='in a fit of several experiments, the one whose parameters the correlation chart '
        'shows (default: the first)',
    )
    return parser


def run_fit(args: argparse.Namespace) -> int:
    # `--dry` promises a byte-identical tree. A scan writes analysis/results.csv DURING the
    # fit, before any persistence decision is reached, so its outputs go to a disposable
    # directory. Nothing is copied — the project is loaded and its scan data read IN PLACE,
    # and
    # `_dry_run_into` makes the disposable directory the project's path, where crysta's driver
    # writes the results (seeding them from the loaded project's committed rows, so a dry run
    # resumes exactly as a real one would). A single or joint fit writes nothing while it runs,
    # and the save below is skipped under --dry. The reports carry numbers and status, never
    # paths; the human header's project name is taken from the original argument.
    with contextlib.ExitStack() as stack:
        project = _open(args)
        if args.dry and _is_scan(project):
            project._dry_run_into(
                stack.enter_context(tempfile.TemporaryDirectory(prefix='edi-dry-'))
            )
        verbosity = _VERBOSITY[args.verbosity]

        with _CancelOnSigint():
            if args.report == 'human':
                code = _run_human(project, verbosity, Path(args.project).name)
            else:
                code = _run_machine(project, verbosity, stream=args.stream)
        if code == _EXIT_CANCELLED:
            print(_resume_hint(project, dry=args.dry), file=sys.stderr)
        # Persist the fitted project by default (results and the pre-fit snapshot are already in
        # the model). The human channel narrates the save; the machine channel writes silently,
        # keeping stdout the versioned record and nothing else. Under --dry this is skipped. A
        # cancelled fit (exit 130) saves nothing.
        if code == 0 and not args.dry:
            if args.report == 'human':
                project.save()
            else:
                project._save_silent()
        return code


# The conventional exit status of a run stopped by SIGINT (128 + 2).
_EXIT_CANCELLED = 130


class _CancelOnSigint:
    """The first Ctrl+C cancels cleanly; the second exits hard.

    The first SIGINT restores the default disposition and raises KeyboardInterrupt. The fit
    runs natively, so the handler runs at the engine's next cancel poll between iterations,
    where edi turns the KeyboardInterrupt into a clean cancel: the fit returns CANCELLED and a
    scan keeps every committed row as its resume point. With the default disposition back, a
    second SIGINT terminates the process at once. The previous handler is restored on exit.
    """

    def __init__(self) -> None:
        self._previous = None

    @staticmethod
    def _on_sigint(_signum: int, _frame: object) -> None:
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        raise KeyboardInterrupt

    def __enter__(self) -> Self:
        self._previous = signal.signal(signal.SIGINT, self._on_sigint)
        return self

    def __exit__(self, *_exc: object) -> None:
        signal.signal(signal.SIGINT, self._previous)


def _exit_code(outcome: object) -> int:
    """130 for a cancelled fit (the SIGINT convention), else 0."""
    return _EXIT_CANCELLED if getattr(outcome, 'status', None) == edi.FitStatus.CANCELLED else 0


def _resume_hint(project: edi.Project, *, dry: bool) -> str:
    """The stderr line a cancelled run ends with: what was kept and how to continue."""
    if not _is_scan(project):
        return 'edi fit: cancelled - the project was left unchanged.'
    if dry:
        return 'edi fit: cancelled - a --dry run keeps nothing; the project was left unchanged.'
    return (
        'edi fit: cancelled - every finished file is kept; run the same command again to resume '
        'from the next file.'
    )


def _fit(project: edi.Project, **kwargs: object):
    """Fit the project via the analysis facade (joint or single per its fitting mode)."""
    return project.analysis.fit(**kwargs)


def _is_scan(project: edi.Project) -> bool:
    """True iff the project declares a scan mode, whose progress a single-fit renderer cannot show.

    . A scan is N fits, so the single-fit streaming contract does not hold over it: the engine
    fires no whole-scan preamble (a fabricated one would report numbers no fit produced), and the
    per-iteration callbacks it does fire restart their numbering at every file. Rendering those
    through the single-fit streamer produced headerless rows, a first `change` computed against a
    synthetic zero, and several restarted sequences run together as if they were one descent.
    """
    # The ONE scan-mode set, from the package (edi/__init__.py), never a second copy here —
    # a duplicated enumeration in the CLI is the same drift class the mode contract just
    # paid for.
    # Independent without a declared scan fits each experiment alone and prints as a single fit
    # (edi ADR-0081).
    return project.analysis.fitting_mode in edi._SCAN_FITTING_MODES and project._scan_declared


def _cancel(cancel) -> dict:
    """The cancel subscriber as a keyword, or none: a call without one passes what it did."""
    return {} if cancel is None else {'should_cancel': cancel}


def _run_human(project: edi.Project, verbosity, project_name: str, *, clock=time.monotonic) -> int:
    return _exit_code(human_fit(project, verbosity, project_name, clock=clock))


def _terminal_columns(*, tty: bool) -> int:
    if not tty:
        return 0
    try:
        return max(1, os.get_terminal_size(sys.stdout.fileno()).columns)
    except (OSError, ValueError, AttributeError):
        return 80


def human_fit(
    project: edi.Project, verbosity, project_name: str, *, clock=time.monotonic, cancel=None
) -> edi.FitResultBase:
    """Fit `project`, printing the human report, and return the fit's outcome.

    `python -m edi fit` prints it, and `project.analysis.fit()` in a notebook.
    """
    # The human report streams for a SINGLE fit: the header + pre-fit row on `on_start`, each
    # iteration row as it completes, the summary after — killing the ~30 s silence. Nothing
    # here formats: the core owns every line (stream_header / iteration_line / summary_line /
    # parameter_table, and for a scan scan_progress_line / scan_summary); this only chooses
    # stdout, flushes per line, and threads `previous`.
    # `clock` is the injected time source for the scan progress line's elapsed/ETA —
    # a zero-argument callable returning seconds. Injected so the values are testable facts
    # rather than wall-clock reads inside assertions; production callers never pass it.
    if verbosity == edi.VerbosityEnum.OFF:
        if _is_scan(project):
            # The OFF contract prints nothing, but a scan fit still declares both scan-event
            # subscribers: the seam is part of the call contract, and OFF gates EMISSION, not
            # subscription. The no-op subscribers write nothing.
            outcome = _fit(
                project,
                **_cancel(cancel),
                on_scan_start=lambda _preamble: None,
                on_file_complete=lambda _record: None,
            )
        else:
            outcome = _fit(
                project, **_cancel(cancel)
            )  # run the fit, print nothing — the OFF contract
        return outcome

    if _is_scan(project):
        # The scan progress view — the whole-scan replacement for the single-fit streaming
        # this branch used to suppress outright. The core fires a scan
        # preamble (carrying the file total) and one completion event per fitted file; this
        # surface renders every line through the core's renderers (edi.scan_progress_line /
        # edi.scan_summary) and only chooses the emission mode: in place on a TTY, one line per
        # file when stdout is not one — notebook-tests, docs and CI read this output, and a
        # carriage return would pollute the logs those gates parse. Per-iteration output is
        # SUPPRESSED at default verbosity (a 213-file scan is ~165,000 iteration rows, which
        # moves the cursor and makes in-place updating impossible) and reachable at FULL, where
        # the progress lines fall back to one-per-file emission for the same cursor reason.
        stream_iterations = verbosity == edi.VerbosityEnum.FULL
        tty = bool(getattr(sys.stdout, 'isatty', lambda: False)()) and not stream_iterations
        started = clock()
        # Review-1 F2 — ONE population, ONE time basis. `tally` folds every committed row of THIS
        # SCAN exactly once: the preamble's already-committed resume rows first, then one per
        # file completed during this call. Every scan-wide quantity below (completed/ok/fail and
        # the χ² range) comes from that one fold, so no counter is seeded from history while the
        # facts beside it describe only this invocation. The fold is INCREMENTAL — the retired
        # form re-scanned every prior row on every event, so file N cost N and a 5 184-file scan
        # slowed quadratically. `prior` marks where this call's rows begin, and it exists for
        # exactly one reason: TIME. A committed row records iterations, never duration, so the
        # injected clock can only ever measure the rows after `prior`, and that count — not the
        # whole-scan total — is what the renderers receive as
        # `measured_completed`.
        # Prose note: this function must not contain the scan line's format literals — the core
        # owns every one of them — so the groups are described here by name, never quoted.
        state = {'total': None, 'elapsed': 0.0}
        tally = _ScanTally()
        prior = [0]
        previous = [0.0]
        variant = edi._edi._metric_variant(project)

        def _emit_progress(line: str) -> None:
            if tty:
                # The core returns the whole terminal update, or nothing when it throttles.
                sys.stdout.write(line)
            else:
                sys.stdout.write(line + '\n')
            sys.stdout.flush()

        def on_scan_start(preamble: object) -> None:
            state['total'] = preamble.total_files
            # Resume seeding: the rows an interrupted earlier run already committed join the
            # scan's population, so a resumed scan starts truthful (`39/213`, not `1/213`) AND
            # can still name the failures among them. Empty on a fresh scan; a preamble source
            # that carries no resume rows (a test fake) means the same thing.
            for row in getattr(preamble, 'completed_rows', []):
                tally.add(row)
            prior[0] = tally.completed
            sys.stdout.write(
                edi._edi._scan_progress_heading(
                    project_name,
                    project.fitting_mode == 'sequential',
                    state['total'],
                    prior[0] > 0,
                    _terminal_columns(tty=tty),
                )
                + '\n'
            )
            sys.stdout.flush()

        def _row(chi2: float, file_name: str, measured: int, *, final_row: bool = False) -> str:
            # Only the closing row names final_row; the others are the plain eleven-value call.
            extra = {'final_row': True} if final_row else {}
            return edi._edi._scan_progress_row(
                tally.completed,
                state['total'],
                state['elapsed'],
                measured,
                tally.ok,
                tally.failed,
                chi2,
                tally.chi2_min,
                tally.chi2_max,
                file_name,
                _terminal_columns(tty=tty),
                **extra,
            )

        def on_file_complete(record: object) -> None:
            tally.add(record)
            state['elapsed'] = clock() - started
            _emit_progress(
                _row(record.reduced_chi_square, record.file_name, tally.completed - prior[0])
            )

        def on_scan_iteration(record: object) -> None:
            sys.stdout.write(edi.iteration_line(record, previous[0], variant) + '\n')
            sys.stdout.flush()
            previous[0] = record.reduced_chi_square

        # The terminal FitResultBase serves only the exit status here: the scan summary below is
        # the whole scan's report, while summary_line / parameter_table describe ONE fit's
        # terminal state, which a scan does not have.
        if stream_iterations:
            outcome = _fit(
                project,
                **_cancel(cancel),
                on_scan_start=on_scan_start,
                on_file_complete=on_file_complete,
                on_iteration=on_scan_iteration,
            )
        else:
            outcome = _fit(
                project,
                **_cancel(cancel),
                on_scan_start=on_scan_start,
                on_file_complete=on_file_complete,
            )
        # The last row is the scan's summary at the count it reached, every column filled and
        # no time left (the core owns its format): a run that fitted no new file prints it once
        # from what the earlier runs left; on a terminal it replaces the in-place row whatever
        # the throttle kept back (a partial or cancelled scan included). Its time is the one
        # read at the last completed file, so the count and the time describe the same moment.
        if tally.completed == prior[0] or tty:
            measured = tally.completed - prior[0]
            final = _row(tally.last_chi2, tally.last_file, measured, final_row=True)
            sys.stdout.write(final + '\n')
        skipped = _skipped_line(project)
        if skipped:
            sys.stdout.write(skipped + '\n')
        sys.stdout.flush()
        return outcome

    return _single_fit(project, verbosity, project_name, cancel)


def _skipped_line(project: edi.Project) -> str:
    """What the scan's results index says about its skipped and refused files.

    The index reads analysis/scan-notes.csv by the rule the app and crysta's resume apply, so a
    file that breaks it is reported as a diagnostic, never as some other state.
    """
    notes = getattr(project, '_scan_notes', None)
    if notes is None or getattr(getattr(project, 'metadata', None), 'path', None) is None:
        return ''
    try:
        report = notes()
    except ValueError as error:
        return f'Scan notes: {error}'
    files, points, refused = report['skipped'], report['negative_points'], report['refused']
    out = []
    if files or points:
        out.append(
            f'Skipped: {files} file(s) with no intensity above zero, '
            f'{points} point(s) with a negative intensity'
        )
    if refused:
        out.append(f'Refused: {len(refused)} file(s), recorded as failed')
        out.extend(f'  {name}: {why}' for name, why in refused[:10])
        if len(refused) > 10:
            out.append(f'  ... and {len(refused) - 10} more')
    if out:
        out.append('(analysis/scan-notes.csv)')
    return '\n'.join(out)


class _ScanTally:
    """The scan-wide aggregates, folded one committed row at a time.

    Constant work per row, so a scan's progress costs the same at file 5 000 as at file 1.
    """

    def __init__(self) -> None:
        self.completed = 0
        self.ok = 0
        self.chi2_min = float('nan')
        self.chi2_max = float('nan')
        # The last completed row's, a resumed run's included, so a final row is complete.
        self.last_chi2 = float('nan')
        self.last_file = ''

    @property
    def failed(self) -> int:
        return self.completed - self.ok

    def add(self, record: object) -> None:
        chi = record.reduced_chi_square
        if not math.isnan(chi):  # a refused file has none
            self.chi2_min = chi if math.isnan(self.chi2_min) else min(self.chi2_min, chi)
            self.chi2_max = chi if math.isnan(self.chi2_max) else max(self.chi2_max, chi)
        self.completed += 1
        self.ok += 1 if record.converged else 0
        self.last_chi2, self.last_file = chi, getattr(record, 'file_name', '')


def _stream_single_fit(project: edi.Project, verbosity, project_name: str) -> int:
    return _exit_code(_single_fit(project, verbosity, project_name))


def _single_fit(project: edi.Project, verbosity, project_name: str, cancel=None):
    # The `change` basis is the previous row's reduced chi2; iteration 1's basis is the pre-fit
    # row's, so it shows its improvement over the initial model. Boxed for the callbacks.
    previous = [0.0]
    # The metrics are named by the fit's sample form: a single crystal's are R(F²) and wR(F²).
    variant = edi._edi._metric_variant(project)

    def on_start(preamble: object) -> None:
        sys.stdout.write(edi.stream_header(preamble, project_name, variant))
        sys.stdout.flush()
        previous[0] = preamble.pre_fit.reduced_chi_square

    def on_iteration(record: object) -> None:
        sys.stdout.write(edi.iteration_line(record, previous[0], variant) + '\n')
        sys.stdout.flush()
        previous[0] = record.reduced_chi_square

    outcome = _fit(project, on_iteration=on_iteration, on_start=on_start, **_cancel(cancel))
    sys.stdout.write(edi.summary_line(outcome, variant))
    if verbosity == edi.VerbosityEnum.FULL:
        sys.stdout.write(edi.parameter_table(outcome, project))
    sys.stdout.flush()
    return outcome


def _run_machine(project: edi.Project, verbosity, *, stream: bool) -> int:
    # The machine channel is the versioned contract on stdout. With --stream, a record=progress is
    # written (flushed) after each accepted step, BEFORE the terminal record=fit; without it, the
    # output is byte-identical to a non-streamed run so the conformance is unaffected. At
    # verbosity off the record is empty, so streaming nothing is the honest OFF behaviour.
    if stream and verbosity != edi.VerbosityEnum.OFF and not _is_scan(project):

        def on_iteration(record: object) -> None:
            sys.stdout.write(edi.progress_report(record))
            sys.stdout.flush()

        outcome = _fit(project, on_iteration=on_iteration)
    else:
        outcome = _fit(project)
    # `end=''` because the core's reports are already newline-terminated, and an extra blank line
    # would be a spurious diff against `crysta fit`.
    report = edi.machine_report(project, outcome, verbosity)
    if report:
        print(report, end='')
    return _exit_code(outcome)


# The idempotence marker, byte-identical to crysta's (src/cli/main.cpp kCalcMarker): everything
# from this line on is regenerated by `calc`. The SHARED literal is load-bearing, not cosmetic —
# either engine's re-run must drop the block the other engine wrote, and the written trees must be
# byte-comparable.
_CALC_MARKER = '# --- calculated series (crysta calc; regenerated on every run) ---'


def _open(args: argparse.Namespace) -> edi.Project:
    """Load the command's project; with --output, save it there first, so every write lands there.

    A .zip project (edi ADR-0052) is never a command's output: without --output nothing is written
    back, as under --dry, and its archive is left as it was (Project.save() in Python rewrites it).
    """
    project = edi.Project.load(args.project)
    if getattr(args, 'output', None) and not args.dry:
        project._save_as_silent(args.output)
        args.project = args.output
    elif Path(args.project).suffix.lower() == '.zip' and not args.dry:
        print(
            f'edi {args.command}: {args.project} is an archive; nothing is written back '
            '(give --output DIR to keep the results)',
            file=sys.stderr,
        )
        args.dry = True
    return project


def run_export(args: argparse.Namespace) -> int:
    """Write the project's folder as one .zip archive, the same archive every surface writes."""
    edi.Project.load(args.project).export_zip(args.output)
    return 0


def _calc_target(directory: str, experiment) -> Path:
    """The experiment document a calc writes back into.

    ADR-0016: the path comes from crysta's one name -> path decision (``edi._entity_path``),
    which refuses by name a datablock name outside the persisted-name domain -- this module
    composes no path from a name itself.
    """
    path = Path(edi._entity_path(directory, 'experiment', experiment.name))
    if not path.is_file():
        raise ValueError(f'cannot write calculated series: {path} does not exist')
    return path


def _write_back_calculated(path: Path, grid, calculated) -> None:
    """Write the calculated series into the experiment's own .edi as a SEPARATE block.

    Mirrors crysta's `write_back_calculated` byte-for-byte: everything before the marker is
    preserved, any previous calculated block is dropped (repeated runs stay idempotent), and the
    `_data_calc` loop is appended. The measured columns are never touched. `{:g}` matches the
    C++ default `operator<<` double formatting (printf %g, 6 significant digits).
    """
    lines = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if line == _CALC_MARKER:
            break
        lines.append(line)
    lines.extend((
        _CALC_MARKER,
        'loop_\n_data_calc.point_id\n_data_calc.x\n_data_calc.intensity_calc',
    ))
    lines.extend(
        f'{index + 1} {grid[index]:g} {value:g}' for index, value in enumerate(calculated)
    )
    # Replaced whole as project output (edi ADR-0039), as the engine's calc does: the document
    # lives in <project>/experiments/.
    _output.write_project_file(path.parent.parent, path, ''.join(f'{line}\n' for line in lines))


def run_calc(args: argparse.Namespace) -> int:
    # The forward-calculation path, through the SAME analysis facade every edi surface uses.
    # The record's numbers are read back from where the facade left the results (each
    # experiment's data.intensity_calc), never computed alongside, so the record and the
    # written series can only describe what the facade actually did.
    started = time.perf_counter()
    project = _open(args)
    # Every experiment's target is resolved (and refused by name when its name cannot be
    # persisted) BEFORE anything is calculated or written, so a refusal leaves the project
    # tree -- and any path outside it -- unchanged.
    # A single crystal's calculated intensities are written with its reflections by the save
    # below, never as a _data_calc block.
    targets = (
        []
        if args.dry
        else [
            _calc_target(args.project, experiment) if experiment.data is not None else None
            for experiment in project.experiments
        ]
    )
    # ADR-0040: an experiment in auto background mode estimates its points or terms first when
    # its data or settings changed; the estimate, with what it came from, is saved with the
    # project unless --dry, as crysta's calc saves it.
    estimating = project._background_estimates_due()
    project.analysis.calculate()
    if not args.dry and estimating:
        project.save()
    elif not args.dry and any(experiment.data is None for experiment in project.experiments):
        project._save_silent()
    total_points = 0
    checksum = 0.0
    for index, experiment in enumerate(project.experiments):
        if experiment.data is None:
            calculated = experiment.refln.intensity_calc
            total_points += len(calculated)
            for value in calculated:
                checksum += value
            continue
        calculated = experiment.data.intensity_calc
        total_points += len(calculated)
        # Accumulated value-by-value in experiment order, exactly as crysta's run_calc folds it —
        # per-experiment partial sums would round differently and break byte-comparability.
        for value in calculated:
            checksum += value
        if not args.dry:
            _write_back_calculated(targets[index], experiment.data.axis(), calculated)
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    verbosity = _VERBOSITY[args.verbosity]
    if getattr(args, 'report', 'machine') == 'human':
        # The human channel, mirroring undo's shape: a readable line, silent at off.
        if verbosity != edi.VerbosityEnum.OFF:
            written = 'left unwritten (--dry)' if args.dry else 'written back'
            sys.stdout.write(
                f'Calculated {total_points} point(s) over '
                f'{len(project.experiments)} experiment(s); the _data_calc series was '
                f'{written}.\n'
            )
        return 0
    # The engine's own emitter (edi core -> crysta format_fit_report); empty at verbosity off.
    record = edi._calc_report(total_points, checksum, elapsed_ms, verbosity)
    if record:
        print(record, end='')
    return 0


def run_undo(args: argparse.Namespace) -> int:
    # Undo the last fit — restore the persisted start state, clear the snapshot, and save the
    # restored project back unless --dry or the outcome was a no-op (a no-op mutates nothing,
    # byte-identically). The machine record mirrors `crysta undo` byte-for-byte.
    project = edi.Project.load(args.project)
    restored, was_no_op = project._undo_fit()
    verbosity = _VERBOSITY[args.verbosity]
    if not args.dry and not was_no_op:
        if args.report == 'human':
            project.save()
        else:
            project._save_silent()
    if verbosity == edi.VerbosityEnum.OFF:
        return 0
    if args.report == 'machine':
        lines = [
            schema_line(edi.error_report(edi.VerbosityEnum.COMPACT)).removesuffix('\n'),
            'record=undo',
            f'was_no_op={"true" if was_no_op else "false"}',
            f'restored={len(restored)}',
        ]
        if verbosity == edi.VerbosityEnum.FULL:
            lines.extend(f'restored_parameter={name}' for name in restored)
        sys.stdout.write('\n'.join(lines) + '\n')
    elif was_no_op:
        sys.stdout.write('Nothing to undo: no fit state is recorded in this project.\n')
    else:
        sys.stdout.write(f'Restored {len(restored)} parameter(s) to their pre-fit state.\n')
        if verbosity == edi.VerbosityEnum.FULL:
            sys.stdout.write(''.join(f'  {name}\n' for name in restored))
    return 0


def run_collection(args: argparse.Namespace) -> int:
    collection = edi.load_collection(args.source)
    if args.action == 'list':
        for entry in collection.entries:
            if args.kind and entry['kind'] != args.kind:
                continue
            columns = (
                entry['id'],
                entry['kind'],
                entry.get('name', ''),
                entry['files'][0]['path'],
            )
            print('\t'.join(columns))
        return 0
    entry = collection.find(args.id)
    if entry is None:
        print(
            f'edi collection: no entry {args.id!r} in {collection.source or "the given index"}',
            file=sys.stderr,
        )
        return 1
    if args.action == 'find':
        print(json.dumps(entry, ensure_ascii=False, indent=1))
        return 0
    print(collection.fetch(args.id, args.into))
    return 0


def run_downloads(args: argparse.Namespace) -> int:
    if args.command == 'list-data':
        edi.list_data(args.kind, source=args.source)
    elif args.command == 'download-data':
        edi.download_data(
            args.name, args.destination, overwrite=args.overwrite, source=args.source
        )
    elif args.command == 'list-tutorials':
        edi.list_tutorials(source=args.source)
    elif args.command == 'download-tutorial':
        formats = [name for name, chosen in (('ipynb', args.ipynb), ('py', args.py)) if chosen]
        for file_format in formats or ['ipynb']:
            edi.download_tutorial(
                args.name,
                args.destination,
                file_format=file_format,
                overwrite=args.overwrite,
                source=args.source,
            )
    else:
        edi.download_all_tutorials(args.destination, overwrite=args.overwrite, source=args.source)
    return 0


def run_report(args: argparse.Namespace) -> int:
    # The project's own report settings, a flag replacing one for this run only; nothing is
    # written to the project. Save report writes the ticked formats but the PDF, which is the
    # app's.
    project = edi.Project.load(args.project)
    if args.check:
        states = project.report.check()
        for name, state in states:
            print(f'{name} {state}')
        return 0 if all(state == 'current' for _name, state in states) else 1
    excluded = [] if args.include_all else args.exclude
    if args.output is not None:
        path = project.report._save_html(
            args.output,
            offline=args.offline,
            x_axis=args.x_axis,
            correlation_threshold=args.correlation_threshold,
            excluded=excluded,
            colour_scheme=args.colour_scheme,
            correlation_experiment=args.correlation_experiment,
        )
        print(f'Wrote {path}')
        return 0
    written = project.report.save(
        offline=args.offline,
        x_axis=args.x_axis,
        correlation_threshold=args.correlation_threshold,
        excluded=excluded,
        colour_scheme=args.colour_scheme,
        correlation_experiment=args.correlation_experiment,
    )
    for path in written:
        print(f'Wrote {path}')
    return 0


def main(argv: list[str] | None = None) -> int:
    # Argument parsing is NOT a run: argparse exits on its own for a usage error, and no record is
    # emitted, because nothing was attempted. Everything below has reached the point of
    # attempting a fit, so a failure there yields the minimal error RECORD on stdout — a parser
    # gets a well-formed "this run produced no fit" rather than silence it cannot distinguish
    # from a crash.
    level, argv = take_log_level(list(sys.argv[1:] if argv is None else argv))
    if level not in LOG_LEVELS:
        build_parser().error(f"--log-level: '{level}' is not one of {', '.join(LOG_LEVELS)}")
    edi.set_log_level(level)
    args = build_parser().parse_args(argv)
    if args.command in {'fit', 'calc'}:
        _native._set_engine_threads(args.threads)
        _native._set_scan_workers(getattr(args, 'parallel_fits', 1))
    # The commands without a fit record: an error is one stderr line beside the non-zero exit.
    plain = {'report': run_report, 'export': run_export, 'collection': run_collection}
    plain.update(
        dict.fromkeys(
            (
                'list-data',
                'download-data',
                'list-tutorials',
                'download-tutorial',
                'download-all-tutorials',
            ),
            run_downloads,
        )
    )
    if args.command in plain:
        try:
            return plain[args.command](args)
        except (edi.IoError, ValueError, OSError) as error:
            print(f'edi {args.command}: {error}', file=sys.stderr)
            return 1
    try:
        if args.command == 'undo':
            return run_undo(args)
        if args.command == 'calc':
            return run_calc(args)
        return run_fit(args)
    except (edi.IoError, ValueError) as error:
        # The record is contract content and goes to stdout; the prose explanation is not, and goes
        # to stderr beside the non-zero exit. At --verbosity off the record is empty and nothing is
        # written, exactly as a successful fit prints nothing there.
        record = edi.error_report(_VERBOSITY[args.verbosity])
        if record:
            print(record, end='')
        print(f'edi fit: {error}', file=sys.stderr)
        # An engine refusal keeps its catalogue code, so a script can tell the causes apart. A file
        # refusal (IoError) carries its diagnostics as mappings, an engine one as objects.
        for diagnostic in getattr(error, 'diagnostics', ()):
            code = diagnostic.get('code') if isinstance(diagnostic, dict) else diagnostic.code
            if code:
                print(f'edi fit: {code}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
